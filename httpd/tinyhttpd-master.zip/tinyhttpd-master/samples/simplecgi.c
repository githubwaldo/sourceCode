#include <stdio.h>
int main(void) {
    printf("Content-Type: text/plain;charset=us-ascii\n\n");
    printf("Hello world in C\n\n");
    return 0;
}
